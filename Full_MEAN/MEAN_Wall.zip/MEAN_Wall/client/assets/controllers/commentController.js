app.controller('commentController', ["$scope", "boardFactory", "$location", "$cookies", function($scope, boardFactory, $location, $cookies){


}])
