var mongoose = require('mongoose');

//SET VARIABLE TO MODEL W/ MONGOOSE.MODEL
var Friend = mongoose.model("Friend");
module.exports = {
    // show: function(req, res) {
    //     Lemur.find({}, function(err, lemurs){
    //         if(err){
    //             console.log(err);
    //             res.redirect('/');
    //         }
    //         else{
    //             res.render("index", {lemurs});
    //         }
    //     })
    // },
}
