var doMath = require('./mathlib.js')();
console.log(doMath.add(4, 5));
console.log(doMath.multiply(7, 9));
console.log(doMath.square(21));
console.log(doMath.random(5, 200));
